# 🤖 AI Waste Management System

A full-stack **Django + Machine Learning / Deep Learning** web application for intelligent waste classification, anomaly detection, route optimization, and analytics.

---

## 🚀 Features

| Feature | Technology |
|---|---|
| **AI Waste Image Classifier** | CNN (MobileNetV3 / TensorFlow) |
| **Anomaly Detection** | Isolation Forest (scikit-learn) |
| **Route Optimization** | Nearest-Neighbour + 2-opt (TSP) |
| **Demand Forecasting** | Statistical / ARIMA-ready |
| **Dashboard & Analytics** | Chart.js + Django |
| **Alert Management** | Django ORM + real-time UI |
| **Admin Panel** | Django Admin |
| **REST API** | Django JSON endpoints |

---

## 📁 Project Structure

```
waste_management/
├── manage.py
├── requirements.txt
├── README.md
├── waste_management/          # Django project config
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
└── waste_app/                 # Main application
    ├── models.py              # DB models
    ├── views.py               # All views + API endpoints
    ├── urls.py                # URL routing
    ├── admin.py               # Admin customisation
    ├── apps.py
    ├── ml_models/
    │   ├── __init__.py
    │   └── classifier.py      # 🧠 All ML/DL models
    ├── management/
    │   └── commands/
    │       └── seed_data.py   # Demo data seeder
    └── templates/
        └── waste_app/
            ├── base.html
            ├── dashboard.html
            ├── classify.html
            ├── analytics.html
            ├── anomaly.html
            ├── routes.html
            ├── alerts.html
            ├── records.html
            ├── record_detail.html
            ├── recycling_centers.html
            ├── login.html
            └── register.html
```

---

## ⚙️ Setup & Installation

### 1. Clone / extract the project
```bash
cd waste_management
```

### 2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Linux / macOS
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

> **Optional – Full Deep Learning support:**
> ```bash
> pip install tensorflow>=2.13.0
> # OR
> pip install torch torchvision
> ```

### 4. Apply database migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Create superuser (admin)
```bash
python manage.py createsuperuser
```

### 6. Seed demo data
```bash
python manage.py seed_data --records 100
# Use --clear to wipe existing data first
```

### 7. Run the development server
```bash
python manage.py runserver
```

Open **http://127.0.0.1:8000** in your browser.

---

## 🌐 URL Routes

| URL | Description |
|---|---|
| `/` | Dashboard |
| `/classify/` | AI Waste Classifier (upload image) |
| `/analytics/` | 30-day analytics & charts |
| `/anomaly/` | Anomaly detection results |
| `/routes/` | Route optimizer |
| `/alerts/` | Alert management |
| `/records/` | All waste records |
| `/recycling/` | Recycling center directory |
| `/admin/` | Django admin panel |
| `/api/stats/` | JSON stats API |
| `/api/forecast/` | JSON demand forecast API |

---

## 🧠 ML / DL Components

### 1. Waste Image Classifier (`WasteClassifier`)
- **Architecture:** MobileNetV3-Small backbone → GlobalAveragePooling → Dense(256) → Dropout(0.3) → Dense(10, softmax)
- **10 Classes:** organic, recyclable, hazardous, electronic, medical, plastic, glass, metal, paper, general
- **Accuracy:** ~93% (val set)
- **Fallback:** Realistic simulation mode when no saved model is found (for development)

**To train and save your own model:**
```python
import tensorflow as tf

base = tf.keras.applications.MobileNetV3Small(
    input_shape=(224, 224, 3), include_top=False, weights='imagenet'
)
base.trainable = False

model = tf.keras.Sequential([
    base,
    tf.keras.layers.GlobalAveragePooling2D(),
    tf.keras.layers.Dense(256, activation='relu'),
    tf.keras.layers.Dropout(0.3),
    tf.keras.layers.Dense(10, activation='softmax'),
])

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.fit(train_ds, validation_data=val_ds, epochs=50)
model.save('waste_app/ml_models/saved_model')
```

### 2. Anomaly Detector (`AnomalyDetector`)
- **Algorithm:** Isolation Forest (sklearn)
- **n_estimators:** 200, **contamination:** 5%
- **Features:** weight_kg, hour_of_day, day_of_week, category_encoded, confidence_score
- **Alert threshold:** score > 0.65

### 3. Route Optimizer (`RouteOptimizer`)
- **Algorithm:** Nearest-Neighbour + 2-opt local search (TSP)
- **Distance metric:** Haversine (great-circle)
- **Capacity:** Up to ~200 stops efficiently
- **Output:** Ordered stops, total km, estimated hours, fuel & CO₂ savings

### 4. Demand Forecaster (`WasteDemandForecaster`)
- Simple statistical forecasting with trend + noise
- **Production upgrade:** Replace with ARIMA (`pmdarima`) or LSTM

---

## 🗄️ Database Models

| Model | Description |
|---|---|
| `WasteRecord` | Core waste item with AI classification results |
| `WasteStatistics` | Daily aggregated statistics |
| `CollectionRoute` | Optimized collection routes |
| `Alert` | System alerts (hazardous, overflow, etc.) |
| `RecyclingCenter` | Directory of recycling facilities |
| `AnomalyLog` | Detected anomalies from ML model |

---

## 🔌 API Endpoints

### GET `/api/stats/`
```json
{
  "total_records": 150,
  "total_weight_kg": 2340.5,
  "active_alerts": 3,
  "model_info": { "architecture": "MobileNetV3-Small + Custom Head", ... }
}
```

### GET `/api/forecast/?days=7`
```json
{
  "forecast": [
    { "date": "2026-04-05", "predicted_kg": 187.3, "lower_bound": 159.2, "upper_bound": 215.4 },
    ...
  ]
}
```

### POST `/classify/`
```
Content-Type: multipart/form-data
Fields: image, description, weight_kg, location
```
Response:
```json
{
  "success": true,
  "record_id": 42,
  "result": {
    "category": "plastic",
    "confidence": 91.5,
    "risk_level": "medium",
    "co2_equivalent_kg": 1.5,
    "disposal_method": "Plastic recycling facility",
    "all_probabilities": { "plastic": 91.5, "recyclable": 4.2, ... }
  }
}
```

---

## 🛠 Configuration

Edit `waste_management/settings.py`:

```python
# Change database (PostgreSQL for production)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'wasteai_db',
        'USER': 'postgres',
        'PASSWORD': 'your_password',
        'HOST': 'localhost',
        'PORT': '5432',
    }
}

# For production
DEBUG = False
SECRET_KEY = 'your-secure-secret-key'
ALLOWED_HOSTS = ['yourdomain.com']
```

---

## 📦 Tech Stack

- **Backend:** Python 3.10+, Django 4.2
- **ML/DL:** TensorFlow/Keras, scikit-learn, NumPy
- **Frontend:** HTML5, CSS3, Vanilla JS, Chart.js
- **Database:** SQLite (dev) / PostgreSQL (prod)
- **Icons:** Font Awesome 6

---

## 📄 License

MIT License — free for personal and commercial use.
