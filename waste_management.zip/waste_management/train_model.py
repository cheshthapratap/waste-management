"""
train_model.py
==============
Script to train and save the CNN waste classifier.

Usage:
    python train_model.py --data_dir /path/to/dataset --epochs 50

Dataset folder structure expected:
    data_dir/
        train/
            organic/      *.jpg
            recyclable/   *.jpg
            hazardous/    *.jpg
            electronic/   *.jpg
            medical/      *.jpg
            plastic/      *.jpg
            glass/        *.jpg
            metal/        *.jpg
            paper/        *.jpg
            general/      *.jpg
        val/
            (same structure)

Recommended datasets:
    - Garbage Classification (Kaggle)
    - TrashNet dataset
    - WasteNet dataset
"""

import argparse
import os
import json

try:
    import tensorflow as tf
    from tensorflow import keras
    TF_AVAILABLE = True
except ImportError:
    TF_AVAILABLE = False
    print("TensorFlow not installed. Run: pip install tensorflow")

CLASSES = [
    'organic', 'recyclable', 'hazardous', 'electronic',
    'medical', 'plastic', 'glass', 'metal', 'paper', 'general'
]
IMG_SIZE = (224, 224)
BATCH_SIZE = 32
SAVE_PATH = 'waste_app/ml_models/saved_model'


def build_model(num_classes: int, fine_tune_layers: int = 20):
    """Build MobileNetV3-based classifier."""
    base = keras.applications.MobileNetV3Small(
        input_shape=(*IMG_SIZE, 3),
        include_top=False,
        weights='imagenet',
        include_preprocessing=True,
    )
    # Freeze all but last N layers
    base.trainable = True
    for layer in base.layers[:-fine_tune_layers]:
        layer.trainable = False

    inputs = keras.Input(shape=(*IMG_SIZE, 3))
    x = base(inputs, training=False)
    x = keras.layers.GlobalAveragePooling2D()(x)
    x = keras.layers.Dense(256, activation='relu')(x)
    x = keras.layers.Dropout(0.3)(x)
    x = keras.layers.BatchNormalization()(x)
    outputs = keras.layers.Dense(num_classes, activation='softmax')(x)

    return keras.Model(inputs, outputs)


def create_datasets(data_dir: str):
    train_ds = keras.utils.image_dataset_from_directory(
        os.path.join(data_dir, 'train'),
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        label_mode='categorical',
        class_names=CLASSES,
        shuffle=True,
        seed=42,
    )
    val_ds = keras.utils.image_dataset_from_directory(
        os.path.join(data_dir, 'val'),
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        label_mode='categorical',
        class_names=CLASSES,
        shuffle=False,
    )

    # Augmentation
    augment = keras.Sequential([
        keras.layers.RandomFlip('horizontal'),
        keras.layers.RandomRotation(0.15),
        keras.layers.RandomZoom(0.1),
        keras.layers.RandomBrightness(0.1),
        keras.layers.RandomContrast(0.1),
    ])

    AUTOTUNE = tf.data.AUTOTUNE
    train_ds = train_ds.map(lambda x, y: (augment(x, training=True), y),
                            num_parallel_calls=AUTOTUNE).prefetch(AUTOTUNE)
    val_ds = val_ds.prefetch(AUTOTUNE)
    return train_ds, val_ds


def train(data_dir: str, epochs: int, lr: float):
    print(f"Building model for {len(CLASSES)} classes...")
    model = build_model(len(CLASSES))

    model.compile(
        optimizer=keras.optimizers.Adam(lr),
        loss='categorical_crossentropy',
        metrics=['accuracy', keras.metrics.TopKCategoricalAccuracy(k=3, name='top3_acc')],
    )
    model.summary()

    train_ds, val_ds = create_datasets(data_dir)

    callbacks = [
        keras.callbacks.ModelCheckpoint(
            SAVE_PATH + '_best',
            save_best_only=True,
            monitor='val_accuracy',
            verbose=1,
        ),
        keras.callbacks.EarlyStopping(
            monitor='val_accuracy',
            patience=8,
            restore_best_weights=True,
            verbose=1,
        ),
        keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=4,
            min_lr=1e-7,
            verbose=1,
        ),
        keras.callbacks.CSVLogger('training_log.csv'),
    ]

    print(f"\nTraining for up to {epochs} epochs...")
    history = model.fit(
        train_ds,
        validation_data=val_ds,
        epochs=epochs,
        callbacks=callbacks,
    )

    # Save final model
    model.save(SAVE_PATH)
    print(f"\nModel saved to: {SAVE_PATH}")

    # Save class mapping
    class_map = {i: cls for i, cls in enumerate(CLASSES)}
    with open('waste_app/ml_models/class_mapping.json', 'w') as f:
        json.dump(class_map, f, indent=2)

    best_val_acc = max(history.history['val_accuracy'])
    print(f"\nBest validation accuracy: {best_val_acc*100:.1f}%")
    return history


if __name__ == '__main__':
    if not TF_AVAILABLE:
        print("Install TensorFlow first: pip install tensorflow")
        exit(1)

    parser = argparse.ArgumentParser(description='Train Waste CNN Classifier')
    parser.add_argument('--data_dir', type=str, required=True,
                        help='Path to dataset directory')
    parser.add_argument('--epochs', type=int, default=50,
                        help='Max training epochs (default: 50)')
    parser.add_argument('--lr', type=float, default=1e-4,
                        help='Learning rate (default: 1e-4)')
    args = parser.parse_args()

    train(args.data_dir, args.epochs, args.lr)
