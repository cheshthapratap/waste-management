from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


WASTE_CATEGORIES = [
    ('organic', 'Organic'),
    ('recyclable', 'Recyclable'),
    ('hazardous', 'Hazardous'),
    ('electronic', 'Electronic (E-Waste)'),
    ('medical', 'Medical'),
    ('plastic', 'Plastic'),
    ('glass', 'Glass'),
    ('metal', 'Metal'),
    ('paper', 'Paper'),
    ('general', 'General Waste'),
]

DISPOSAL_METHODS = {
    'organic': 'Compost or send to biogas plant',
    'recyclable': 'Send to recycling center',
    'hazardous': 'Contact hazardous waste disposal authority',
    'electronic': 'E-waste collection center',
    'medical': 'Medical waste incinerator',
    'plastic': 'Plastic recycling facility',
    'glass': 'Glass recycling center',
    'metal': 'Metal scrap yard or recycling',
    'paper': 'Paper recycling mill',
    'general': 'Municipal solid waste facility',
}

RISK_LEVELS = [
    ('low', 'Low'),
    ('medium', 'Medium'),
    ('high', 'High'),
    ('critical', 'Critical'),
]


class WasteRecord(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    image = models.ImageField(upload_to='uploads/', null=True, blank=True)
    description = models.TextField(blank=True)
    predicted_category = models.CharField(max_length=50, choices=WASTE_CATEGORIES, blank=True)
    confidence_score = models.FloatField(default=0.0)
    disposal_method = models.TextField(blank=True)
    risk_level = models.CharField(max_length=20, choices=RISK_LEVELS, default='low')
    weight_kg = models.FloatField(default=0.0)
    location = models.CharField(max_length=255, blank=True)
    is_processed = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    environmental_impact_score = models.FloatField(default=0.0)
    co2_equivalent_kg = models.FloatField(default=0.0)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Waste #{self.id} - {self.predicted_category} ({self.created_at.date()})"

    def save(self, *args, **kwargs):
        if self.predicted_category:
            self.disposal_method = DISPOSAL_METHODS.get(self.predicted_category, 'Contact local waste authority')
        super().save(*args, **kwargs)


class WasteStatistics(models.Model):
    date = models.DateField(unique=True)
    total_waste_kg = models.FloatField(default=0.0)
    organic_kg = models.FloatField(default=0.0)
    recyclable_kg = models.FloatField(default=0.0)
    hazardous_kg = models.FloatField(default=0.0)
    electronic_kg = models.FloatField(default=0.0)
    plastic_kg = models.FloatField(default=0.0)
    glass_kg = models.FloatField(default=0.0)
    metal_kg = models.FloatField(default=0.0)
    paper_kg = models.FloatField(default=0.0)
    general_kg = models.FloatField(default=0.0)
    total_records = models.IntegerField(default=0)
    co2_saved_kg = models.FloatField(default=0.0)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f"Stats for {self.date}"


class CollectionRoute(models.Model):
    name = models.CharField(max_length=100)
    zones = models.JSONField(default=list)
    optimized_path = models.JSONField(default=list)
    total_distance_km = models.FloatField(default=0.0)
    estimated_time_hours = models.FloatField(default=0.0)
    waste_category = models.CharField(max_length=50, choices=WASTE_CATEGORIES, default='general')
    scheduled_date = models.DateField()
    is_completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Route: {self.name} ({self.scheduled_date})"


class Alert(models.Model):
    ALERT_TYPES = [
        ('overflow', 'Bin Overflow'),
        ('hazardous', 'Hazardous Waste Detected'),
        ('missed_collection', 'Missed Collection'),
        ('high_volume', 'High Volume Alert'),
        ('anomaly', 'Anomaly Detected'),
    ]
    alert_type = models.CharField(max_length=50, choices=ALERT_TYPES)
    message = models.TextField()
    location = models.CharField(max_length=255, blank=True)
    is_resolved = models.BooleanField(default=False)
    severity = models.CharField(max_length=20, choices=RISK_LEVELS, default='medium')
    waste_record = models.ForeignKey(WasteRecord, on_delete=models.SET_NULL, null=True, blank=True)
    created_at = models.DateTimeField(default=timezone.now)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"Alert: {self.alert_type} - {self.created_at.date()}"


class RecyclingCenter(models.Model):
    name = models.CharField(max_length=200)
    address = models.TextField()
    latitude = models.FloatField()
    longitude = models.FloatField()
    accepted_categories = models.JSONField(default=list)
    operating_hours = models.CharField(max_length=200)
    contact_number = models.CharField(max_length=20, blank=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class AnomalyLog(models.Model):
    detection_time = models.DateTimeField(default=timezone.now)
    anomaly_type = models.CharField(max_length=100)
    description = models.TextField()
    location = models.CharField(max_length=255, blank=True)
    severity_score = models.FloatField(default=0.0)
    is_false_positive = models.BooleanField(default=False)
    ml_model_used = models.CharField(max_length=100, blank=True)
    confidence = models.FloatField(default=0.0)

    class Meta:
        ordering = ['-detection_time']

    def __str__(self):
        return f"Anomaly: {self.anomaly_type} at {self.detection_time}"
