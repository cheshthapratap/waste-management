"""
Management command: python manage.py seed_data

Seeds the database with realistic demo data for development & testing.
"""
import random
from datetime import datetime, timedelta
from django.core.management.base import BaseCommand
from django.utils import timezone
from waste_app.models import (
    WasteRecord, Alert, RecyclingCenter, AnomalyLog, CollectionRoute
)


CATEGORIES = ['organic', 'recyclable', 'hazardous', 'electronic',
               'medical', 'plastic', 'glass', 'metal', 'paper', 'general']
RISK_BY_CAT = {
    'organic': 'low', 'recyclable': 'low', 'hazardous': 'critical',
    'electronic': 'high', 'medical': 'critical', 'plastic': 'medium',
    'glass': 'low', 'metal': 'low', 'paper': 'low', 'general': 'medium',
}
LOCATIONS = [
    'Zone A - Block 1', 'Zone B - Market Area', 'Zone C - Industrial',
    'Zone D - Residential', 'Zone E - Hospital Area', 'Zone F - Commercial',
]
DISPOSAL_METHODS = {
    'organic': 'Compost or send to biogas plant',
    'recyclable': 'Send to recycling center',
    'hazardous': 'Contact hazardous waste disposal authority',
    'electronic': 'E-waste collection center',
    'medical': 'Medical waste incinerator',
    'plastic': 'Plastic recycling facility',
    'glass': 'Glass recycling center',
    'metal': 'Metal scrap yard or recycling',
    'paper': 'Paper recycling mill',
    'general': 'Municipal solid waste facility',
}
CO2_FACTORS = {
    'organic': 0.5, 'recyclable': 0.3, 'hazardous': 2.5, 'electronic': 3.0,
    'medical': 4.0, 'plastic': 1.5, 'glass': 0.8, 'metal': 1.2,
    'paper': 0.4, 'general': 1.0,
}
ENV_IMPACT = {
    'organic': 2, 'recyclable': 1, 'hazardous': 10, 'electronic': 9,
    'medical': 10, 'plastic': 7, 'glass': 3, 'metal': 4, 'paper': 2, 'general': 5,
}


class Command(BaseCommand):
    help = 'Seed database with demo data'

    def add_arguments(self, parser):
        parser.add_argument('--records', type=int, default=60,
                            help='Number of waste records to create')
        parser.add_argument('--clear', action='store_true',
                            help='Clear existing data before seeding')

    def handle(self, *args, **options):
        if options['clear']:
            self.stdout.write('Clearing existing data...')
            WasteRecord.objects.all().delete()
            Alert.objects.all().delete()
            AnomalyLog.objects.all().delete()
            CollectionRoute.objects.all().delete()
            RecyclingCenter.objects.all().delete()

        n = options['records']
        self.stdout.write(f'Creating {n} waste records...')

        for i in range(n):
            cat = random.choice(CATEGORIES)
            weight = round(random.uniform(0.5, 50.0), 2)
            conf = round(random.uniform(0.60, 0.99), 4)
            days_ago = random.randint(0, 30)
            created = timezone.now() - timedelta(
                days=days_ago,
                hours=random.randint(0, 23),
                minutes=random.randint(0, 59),
            )

            r = WasteRecord(
                predicted_category=cat,
                confidence_score=conf,
                disposal_method=DISPOSAL_METHODS[cat],
                risk_level=RISK_BY_CAT[cat],
                weight_kg=weight,
                location=random.choice(LOCATIONS),
                environmental_impact_score=ENV_IMPACT[cat],
                co2_equivalent_kg=round(CO2_FACTORS[cat] * weight, 3),
                description=f'Demo {cat} waste item #{i+1}',
                is_processed=random.choice([True, False]),
            )
            r.save()
            # Override auto_now_add timestamp
            WasteRecord.objects.filter(pk=r.pk).update(created_at=created)

            # Random alerts for high-risk
            if RISK_BY_CAT[cat] in ('critical', 'high') and random.random() < 0.5:
                Alert.objects.create(
                    alert_type='hazardous',
                    message=f'High-risk waste detected: {cat} ({weight} kg)',
                    location=r.location,
                    severity=RISK_BY_CAT[cat],
                    waste_record=r,
                )

        self.stdout.write('Creating recycling centers...')
        centers = [
            {
                'name': 'Central Recycling Hub',
                'address': 'Industrial Area, Zone C',
                'latitude': 22.7196, 'longitude': 75.8577,
                'accepted_categories': ['plastic', 'glass', 'metal', 'paper', 'recyclable'],
                'operating_hours': 'Mon-Sat: 8AM - 6PM',
                'contact_number': '+91-731-000-0001',
            },
            {
                'name': 'E-Waste Collection Center',
                'address': 'Tech Park, Zone B',
                'latitude': 22.7250, 'longitude': 75.8650,
                'accepted_categories': ['electronic'],
                'operating_hours': 'Mon-Fri: 9AM - 5PM',
                'contact_number': '+91-731-000-0002',
            },
            {
                'name': 'Hazardous Waste Facility',
                'address': 'Outer Ring Road, Zone F',
                'latitude': 22.7100, 'longitude': 75.8500,
                'accepted_categories': ['hazardous', 'medical', 'chemical'],
                'operating_hours': 'Mon-Sat: 7AM - 7PM',
                'contact_number': '+91-731-000-0003',
            },
            {
                'name': 'Organic Compost Plant',
                'address': 'Agricultural Zone, Zone A',
                'latitude': 22.7300, 'longitude': 75.8700,
                'accepted_categories': ['organic'],
                'operating_hours': '24/7',
                'contact_number': '+91-731-000-0004',
            },
        ]
        for c in centers:
            RecyclingCenter.objects.get_or_create(name=c['name'], defaults=c)

        self.stdout.write('Creating anomaly logs...')
        anomaly_types = [
            'Unusual waste volume spike', 'Unexpected hazardous material',
            'Abnormal collection frequency', 'Temporal pattern deviation',
        ]
        for _ in range(8):
            AnomalyLog.objects.create(
                anomaly_type=random.choice(anomaly_types),
                description='Anomalous waste pattern detected by Isolation Forest.',
                location=random.choice(LOCATIONS),
                severity_score=round(random.uniform(0.65, 0.98), 3),
                confidence=round(random.uniform(65, 98), 1),
                ml_model_used='Isolation Forest',
                is_false_positive=random.random() < 0.1,
            )

        self.stdout.write('Creating collection routes...')
        from datetime import date
        for i, cat in enumerate(['general', 'recyclable', 'organic', 'hazardous']):
            CollectionRoute.objects.create(
                name=f'{cat.title()} Collection Route {i+1}',
                waste_category=cat,
                scheduled_date=date.today() + timedelta(days=i),
                total_distance_km=round(random.uniform(20, 80), 1),
                estimated_time_hours=round(random.uniform(2, 6), 1),
                zones=LOCATIONS[:3],
                optimized_path=[],
                is_completed=(i == 0),
            )

        self.stdout.write(self.style.SUCCESS(
            f'\n✅ Seeding complete!\n'
            f'   Waste records : {WasteRecord.objects.count()}\n'
            f'   Alerts        : {Alert.objects.count()}\n'
            f'   Centers       : {RecyclingCenter.objects.count()}\n'
            f'   Anomaly logs  : {AnomalyLog.objects.count()}\n'
            f'   Routes        : {CollectionRoute.objects.count()}\n'
        ))
