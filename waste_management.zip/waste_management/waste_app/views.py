import json
import random
from datetime import datetime, timedelta
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.db.models import Sum, Count, Avg
from django.utils import timezone

from .models import (
    WasteRecord, WasteStatistics, CollectionRoute,
    Alert, RecyclingCenter, AnomalyLog
)
from .ml_models.classifier import (
    classifier, anomaly_detector,
    route_optimizer, demand_forecaster
)


# ─────────────────────────────────────────────────────────
# DASHBOARD
# ─────────────────────────────────────────────────────────

def dashboard(request):
    total_records = WasteRecord.objects.count()
    total_weight = WasteRecord.objects.aggregate(Sum('weight_kg'))['weight_kg__sum'] or 0
    active_alerts = Alert.objects.filter(is_resolved=False).count()
    avg_confidence = WasteRecord.objects.aggregate(Avg('confidence_score'))['confidence_score__avg'] or 0

    # Category distribution
    category_data = (
        WasteRecord.objects
        .values('predicted_category')
        .annotate(count=Count('id'), total_weight=Sum('weight_kg'))
        .order_by('-count')
    )

    # Last 7 days trend
    trend_labels, trend_data = [], []
    for i in range(6, -1, -1):
        day = timezone.now().date() - timedelta(days=i)
        total = WasteRecord.objects.filter(
            created_at__date=day
        ).aggregate(Sum('weight_kg'))['weight_kg__sum'] or 0
        trend_labels.append(day.strftime('%a'))
        trend_data.append(round(float(total), 2))

    # Recent alerts
    recent_alerts = Alert.objects.filter(is_resolved=False).order_by('-created_at')[:5]

    # Forecast
    historical = trend_data
    forecast = demand_forecaster.forecast(historical, days_ahead=7)

    context = {
        'total_records': total_records,
        'total_weight': round(total_weight, 1),
        'active_alerts': active_alerts,
        'avg_confidence': round(avg_confidence * 100, 1),
        'category_data': json.dumps(list(category_data)),
        'trend_labels': json.dumps(trend_labels),
        'trend_data': json.dumps(trend_data),
        'recent_alerts': recent_alerts,
        'forecast': json.dumps(forecast),
        'model_info': classifier.get_model_info(),
    }
    return render(request, 'waste_app/dashboard.html', context)


# ─────────────────────────────────────────────────────────
# WASTE CLASSIFICATION
# ─────────────────────────────────────────────────────────

def classify_waste(request):
    if request.method == 'POST':
        image = request.FILES.get('image')
        description = request.POST.get('description', '')
        weight = float(request.POST.get('weight_kg', 0))
        location = request.POST.get('location', '')

        result = classifier.predict(
            image_path=image.temporary_file_path() if hasattr(image, 'temporary_file_path') else None
        )

        record = WasteRecord.objects.create(
            user=request.user if request.user.is_authenticated else None,
            image=image,
            description=description,
            predicted_category=result['category'],
            confidence_score=result['confidence'] / 100,
            disposal_method=result['disposal_method'],
            risk_level=result['risk_level'],
            weight_kg=weight,
            location=location,
            environmental_impact_score=result['environmental_impact_score'],
            co2_equivalent_kg=result['co2_equivalent_kg'] * weight if weight else result['co2_equivalent_kg'],
        )

        # Auto-create alert for hazardous/medical
        if result['risk_level'] in ('critical', 'high'):
            Alert.objects.create(
                alert_type='hazardous',
                message=f"High-risk waste detected: {result['category']} at {location or 'unknown location'}",
                location=location,
                severity=result['risk_level'],
                waste_record=record,
            )

        return JsonResponse({
            'success': True,
            'record_id': record.id,
            'result': result,
        })

    return render(request, 'waste_app/classify.html', {
        'model_info': classifier.get_model_info()
    })


# ─────────────────────────────────────────────────────────
# ANALYTICS
# ─────────────────────────────────────────────────────────

def analytics(request):
    # Per-category aggregates
    cat_stats = (
        WasteRecord.objects
        .values('predicted_category')
        .annotate(
            count=Count('id'),
            total_weight=Sum('weight_kg'),
            avg_confidence=Avg('confidence_score'),
            total_co2=Sum('co2_equivalent_kg'),
        )
    )

    # 30-day daily trend
    dates, weights = [], []
    for i in range(29, -1, -1):
        day = timezone.now().date() - timedelta(days=i)
        w = WasteRecord.objects.filter(
            created_at__date=day
        ).aggregate(Sum('weight_kg'))['weight_kg__sum'] or 0
        dates.append(day.strftime('%b %d'))
        weights.append(round(float(w), 2))

    # Risk level distribution
    risk_counts = {
        'low': WasteRecord.objects.filter(risk_level='low').count(),
        'medium': WasteRecord.objects.filter(risk_level='medium').count(),
        'high': WasteRecord.objects.filter(risk_level='high').count(),
        'critical': WasteRecord.objects.filter(risk_level='critical').count(),
    }

    total_co2 = WasteRecord.objects.aggregate(Sum('co2_equivalent_kg'))['co2_equivalent_kg__sum'] or 0

    context = {
        'cat_stats': list(cat_stats),
        'dates': json.dumps(dates),
        'weights': json.dumps(weights),
        'risk_counts': json.dumps(risk_counts),
        'total_co2': round(total_co2, 2),
        'total_records': WasteRecord.objects.count(),
        'total_weight': round(
            WasteRecord.objects.aggregate(Sum('weight_kg'))['weight_kg__sum'] or 0, 1
        ),
    }
    return render(request, 'waste_app/analytics.html', context)


# ─────────────────────────────────────────────────────────
# ANOMALY DETECTION
# ─────────────────────────────────────────────────────────

def anomaly_detection(request):
    recent_records = WasteRecord.objects.order_by('-created_at')[:50]
    anomalies = anomaly_detector.detect(list(recent_records))

    # Persist new anomalies
    for a in anomalies:
        AnomalyLog.objects.get_or_create(
            detection_time__date=timezone.now().date(),
            anomaly_type=a['anomaly_type'],
            defaults={
                'description': a['description'],
                'severity_score': a['severity_score'],
                'confidence': a['confidence'],
                'ml_model_used': 'Isolation Forest',
            }
        )

    all_logs = AnomalyLog.objects.order_by('-detection_time')[:20]

    context = {
        'anomalies': anomalies,
        'anomaly_logs': all_logs,
        'total_anomalies': len(anomalies),
        'high_severity': sum(1 for a in anomalies if a['severity_score'] > 0.8),
    }
    return render(request, 'waste_app/anomaly.html', context)


# ─────────────────────────────────────────────────────────
# ROUTE OPTIMIZATION
# ─────────────────────────────────────────────────────────

def route_optimization(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        locations = data.get('locations', [])
        result = route_optimizer.optimize(locations)
        return JsonResponse(result)

    # Demo locations (replace with real DB data)
    demo_locations = [
        {'id': i, 'lat': 22.7196 + random.uniform(-0.05, 0.05),
         'lon': 75.8577 + random.uniform(-0.05, 0.05),
         'waste_volume': random.uniform(50, 500),
         'name': f'Collection Point {i}'}
        for i in range(1, 11)
    ]
    demo_result = route_optimizer.optimize(demo_locations)

    routes = CollectionRoute.objects.order_by('-created_at')[:10]
    context = {
        'demo_locations': json.dumps(demo_locations),
        'demo_result': json.dumps(demo_result),
        'routes': routes,
    }
    return render(request, 'waste_app/routes.html', context)


# ─────────────────────────────────────────────────────────
# ALERTS
# ─────────────────────────────────────────────────────────

def alerts_view(request):
    alerts = Alert.objects.order_by('-created_at')
    unresolved = alerts.filter(is_resolved=False)
    context = {
        'alerts': alerts[:20],
        'unresolved_count': unresolved.count(),
        'critical_count': unresolved.filter(severity='critical').count(),
    }
    return render(request, 'waste_app/alerts.html', context)


@csrf_exempt
def resolve_alert(request, alert_id):
    if request.method == 'POST':
        alert = get_object_or_404(Alert, id=alert_id)
        alert.is_resolved = True
        alert.resolved_at = timezone.now()
        alert.save()
        return JsonResponse({'success': True})
    return JsonResponse({'error': 'POST required'}, status=405)


# ─────────────────────────────────────────────────────────
# WASTE RECORDS  (list + detail)
# ─────────────────────────────────────────────────────────

def waste_records(request):
    records = WasteRecord.objects.order_by('-created_at')[:50]
    return render(request, 'waste_app/records.html', {'records': records})


def waste_record_detail(request, record_id):
    record = get_object_or_404(WasteRecord, id=record_id)
    return render(request, 'waste_app/record_detail.html', {'record': record})


# ─────────────────────────────────────────────────────────
# RECYCLING CENTRES
# ─────────────────────────────────────────────────────────

def recycling_centers(request):
    centers = RecyclingCenter.objects.filter(is_active=True)
    return render(request, 'waste_app/recycling_centers.html', {'centers': centers})


# ─────────────────────────────────────────────────────────
# API  (JSON endpoints)
# ─────────────────────────────────────────────────────────

def api_stats(request):
    return JsonResponse({
        'total_records': WasteRecord.objects.count(),
        'total_weight_kg': WasteRecord.objects.aggregate(
            Sum('weight_kg'))['weight_kg__sum'] or 0,
        'active_alerts': Alert.objects.filter(is_resolved=False).count(),
        'model_info': classifier.get_model_info(),
    })


def api_forecast(request):
    days = int(request.GET.get('days', 7))
    historical = [
        float(WasteRecord.objects.filter(
            created_at__date=timezone.now().date() - timedelta(days=i)
        ).aggregate(Sum('weight_kg'))['weight_kg__sum'] or random.uniform(80, 200))
        for i in range(14, 0, -1)
    ]
    forecast = demand_forecaster.forecast(historical, days_ahead=days)
    return JsonResponse({'forecast': forecast})


# ─────────────────────────────────────────────────────────
# AUTH
# ─────────────────────────────────────────────────────────

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
        return render(request, 'waste_app/login.html', {'error': 'Invalid credentials'})
    return render(request, 'waste_app/login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


def register_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST.get('email', '')
        password = request.POST['password']
        if User.objects.filter(username=username).exists():
            return render(request, 'waste_app/register.html', {'error': 'Username taken'})
        user = User.objects.create_user(username=username, email=email, password=password)
        login(request, user)
        return redirect('dashboard')
    return render(request, 'waste_app/register.html')
