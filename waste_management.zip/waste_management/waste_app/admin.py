from django.contrib import admin
from .models import WasteRecord, WasteStatistics, CollectionRoute, Alert, RecyclingCenter, AnomalyLog


@admin.register(WasteRecord)
class WasteRecordAdmin(admin.ModelAdmin):
    list_display = ['id', 'predicted_category', 'confidence_score', 'risk_level', 'weight_kg', 'location', 'created_at']
    list_filter = ['predicted_category', 'risk_level', 'is_processed']
    search_fields = ['description', 'location']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Alert)
class AlertAdmin(admin.ModelAdmin):
    list_display = ['id', 'alert_type', 'severity', 'location', 'is_resolved', 'created_at']
    list_filter = ['alert_type', 'severity', 'is_resolved']
    actions = ['mark_resolved']

    def mark_resolved(self, request, queryset):
        from django.utils import timezone
        queryset.update(is_resolved=True, resolved_at=timezone.now())
    mark_resolved.short_description = "Mark selected alerts as resolved"


@admin.register(CollectionRoute)
class CollectionRouteAdmin(admin.ModelAdmin):
    list_display = ['name', 'waste_category', 'scheduled_date', 'total_distance_km', 'is_completed']
    list_filter = ['waste_category', 'is_completed']


@admin.register(RecyclingCenter)
class RecyclingCenterAdmin(admin.ModelAdmin):
    list_display = ['name', 'address', 'is_active']
    list_filter = ['is_active']


@admin.register(AnomalyLog)
class AnomalyLogAdmin(admin.ModelAdmin):
    list_display = ['anomaly_type', 'severity_score', 'confidence', 'detection_time', 'is_false_positive']
    list_filter = ['anomaly_type', 'is_false_positive']


admin.site.register(WasteStatistics)
