from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('classify/', views.classify_waste, name='classify'),
    path('analytics/', views.analytics, name='analytics'),
    path('anomaly/', views.anomaly_detection, name='anomaly'),
    path('routes/', views.route_optimization, name='routes'),
    path('alerts/', views.alerts_view, name='alerts'),
    path('alerts/resolve/<int:alert_id>/', views.resolve_alert, name='resolve_alert'),
    path('records/', views.waste_records, name='records'),
    path('records/<int:record_id>/', views.waste_record_detail, name='record_detail'),
    path('recycling/', views.recycling_centers, name='recycling_centers'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),
    # API
    path('api/stats/', views.api_stats, name='api_stats'),
    path('api/forecast/', views.api_forecast, name='api_forecast'),
]
