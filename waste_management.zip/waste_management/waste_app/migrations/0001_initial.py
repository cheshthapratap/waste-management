from django.db import migrations, models
import django.db.models.deletion
import django.utils.timezone


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('auth', '0012_alter_user_first_name_max_length'),
    ]

    operations = [
        migrations.CreateModel(
            name='WasteRecord',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('image', models.ImageField(blank=True, null=True, upload_to='uploads/')),
                ('description', models.TextField(blank=True)),
                ('predicted_category', models.CharField(blank=True, choices=[('organic', 'Organic'), ('recyclable', 'Recyclable'), ('hazardous', 'Hazardous'), ('electronic', 'Electronic (E-Waste)'), ('medical', 'Medical'), ('plastic', 'Plastic'), ('glass', 'Glass'), ('metal', 'Metal'), ('paper', 'Paper'), ('general', 'General Waste')], max_length=50)),
                ('confidence_score', models.FloatField(default=0.0)),
                ('disposal_method', models.TextField(blank=True)),
                ('risk_level', models.CharField(choices=[('low', 'Low'), ('medium', 'Medium'), ('high', 'High'), ('critical', 'Critical')], default='low', max_length=20)),
                ('weight_kg', models.FloatField(default=0.0)),
                ('location', models.CharField(blank=True, max_length=255)),
                ('is_processed', models.BooleanField(default=False)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('environmental_impact_score', models.FloatField(default=0.0)),
                ('co2_equivalent_kg', models.FloatField(default=0.0)),
                ('user', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='auth.user')),
            ],
            options={'ordering': ['-created_at']},
        ),
        migrations.CreateModel(
            name='WasteStatistics',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('date', models.DateField(unique=True)),
                ('total_waste_kg', models.FloatField(default=0.0)),
                ('organic_kg', models.FloatField(default=0.0)),
                ('recyclable_kg', models.FloatField(default=0.0)),
                ('hazardous_kg', models.FloatField(default=0.0)),
                ('electronic_kg', models.FloatField(default=0.0)),
                ('plastic_kg', models.FloatField(default=0.0)),
                ('glass_kg', models.FloatField(default=0.0)),
                ('metal_kg', models.FloatField(default=0.0)),
                ('paper_kg', models.FloatField(default=0.0)),
                ('general_kg', models.FloatField(default=0.0)),
                ('total_records', models.IntegerField(default=0)),
                ('co2_saved_kg', models.FloatField(default=0.0)),
            ],
            options={'ordering': ['-date']},
        ),
        migrations.CreateModel(
            name='RecyclingCenter',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=200)),
                ('address', models.TextField()),
                ('latitude', models.FloatField()),
                ('longitude', models.FloatField()),
                ('accepted_categories', models.JSONField(default=list)),
                ('operating_hours', models.CharField(max_length=200)),
                ('contact_number', models.CharField(blank=True, max_length=20)),
                ('is_active', models.BooleanField(default=True)),
            ],
        ),
        migrations.CreateModel(
            name='CollectionRoute',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('name', models.CharField(max_length=100)),
                ('zones', models.JSONField(default=list)),
                ('optimized_path', models.JSONField(default=list)),
                ('total_distance_km', models.FloatField(default=0.0)),
                ('estimated_time_hours', models.FloatField(default=0.0)),
                ('waste_category', models.CharField(choices=[('organic', 'Organic'), ('recyclable', 'Recyclable'), ('hazardous', 'Hazardous'), ('electronic', 'Electronic (E-Waste)'), ('medical', 'Medical'), ('plastic', 'Plastic'), ('glass', 'Glass'), ('metal', 'Metal'), ('paper', 'Paper'), ('general', 'General Waste')], default='general', max_length=50)),
                ('scheduled_date', models.DateField()),
                ('is_completed', models.BooleanField(default=False)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
            ],
        ),
        migrations.CreateModel(
            name='Alert',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('alert_type', models.CharField(choices=[('overflow', 'Bin Overflow'), ('hazardous', 'Hazardous Waste Detected'), ('missed_collection', 'Missed Collection'), ('high_volume', 'High Volume Alert'), ('anomaly', 'Anomaly Detected')], max_length=50)),
                ('message', models.TextField()),
                ('location', models.CharField(blank=True, max_length=255)),
                ('is_resolved', models.BooleanField(default=False)),
                ('severity', models.CharField(choices=[('low', 'Low'), ('medium', 'Medium'), ('high', 'High'), ('critical', 'Critical')], default='medium', max_length=20)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now)),
                ('resolved_at', models.DateTimeField(blank=True, null=True)),
                ('waste_record', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to='waste_app.wasterecord')),
            ],
            options={'ordering': ['-created_at']},
        ),
        migrations.CreateModel(
            name='AnomalyLog',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('detection_time', models.DateTimeField(default=django.utils.timezone.now)),
                ('anomaly_type', models.CharField(max_length=100)),
                ('description', models.TextField()),
                ('location', models.CharField(blank=True, max_length=255)),
                ('severity_score', models.FloatField(default=0.0)),
                ('is_false_positive', models.BooleanField(default=False)),
                ('ml_model_used', models.CharField(blank=True, max_length=100)),
                ('confidence', models.FloatField(default=0.0)),
            ],
            options={'ordering': ['-detection_time']},
        ),
    ]
